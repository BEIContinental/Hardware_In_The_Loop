//
// File: gearbox_and_differential_types.h
//
// Code generated for Simulink model 'gearbox_and_differential'.
//
// Model version                  : 1.2
// Simulink Coder version         : 8.10 (R2016a) 10-Feb-2016
// C/C++ source code generated on : Fri Jan 26 02:56:48 2018
//
// Target selection: ert.tlc
// Embedded hardware selection: Intel->x86-64 (Windows64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_gearbox_and_differential_types_h_
#define RTW_HEADER_gearbox_and_differential_types_h_

// Forward declaration for rtModel
typedef struct tag_RTM_gearbox_and_different_T RT_MODEL_gearbox_and_differen_T;

#endif                                 // RTW_HEADER_gearbox_and_differential_types_h_ 

//
// File trailer for generated code.
//
// [EOF]
//
